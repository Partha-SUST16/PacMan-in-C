#include<stdio.h>
#include<stdlib.h>
#include<dos.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#include <windows.h>
#include <mmsystem.h>
#include<bits/stdc++.h>

char ch,sc[10],hc[10],lf[20];
int scs,highscore;
int maxx,maxy,gridx,gridy,level = 1;
int gd=DETECT, gm;
int score= 0,rep=0,death,dark=0,t=300,tot=0;
int map[20][19];
int x=9,y=14,x1=7,x2=11,x3=7,Y1=8,Y2=8,y3=10,dir=0,st=120,end=60;
int tx2,tY2,tx3,ty3,r3;
float offset;
void kill();
void ghost1();
void ghost2();
void ghost3();
void initialize()
{
//  int i,j;
//  /0->BLOCK; 1->FOOD; 2->BLACK Space
//  int m[20][19]={
//{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
//{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
//{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
//{0,1,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0},
//{0,1,1,1,0,0,0,0,1,1,1,0,1,1,1,1,1,1,0},
//{0,1,1,1,0,0,0,0,1,1,1,0,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,0},
//{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
//{0,1,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,0},
//{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
//{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};
//
//for(i=0;i<20;i++)
//{
//  for(j=0;j<19;j++)
//    map[i][j]=m[i][j];
//}

death=0,dark=0;
score=0;
initwindow(800,600);
maxx=getmaxx();
maxy=getmaxy();

setviewport(0,0,maxx,maxy,1);
gridx=ceil(maxx/19);
gridy=ceil(maxy/20);
offset=(maxx%19)/2;
}
void initialize1()
{
  int i,j;
  ///0->BLOCK; 1->FOOD; 2->BLACK Space
  int m[20][19]={
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,0},
{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,0},
{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0},
{0,1,1,1,0,0,0,0,1,1,1,0,1,1,1,1,1,1,0},
{0,1,1,1,0,0,0,0,1,1,1,0,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,0,1,0},
{0,1,0,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0},
{0,1,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};

for(i=0;i<20;i++)
{
  for(j=0;j<19;j++)
    map[i][j]=m[i][j];
}

death=0,dark=0;
score=0;
//initwindow(800,600);
maxx=getmaxx();
maxy=getmaxy();

//setviewport(0,0,maxx,maxy,1);
gridx=ceil(maxx/19);
gridy=ceil(maxy/20);
offset=(maxx%19)/2;
}
void initialize5()
{
  int i,j;
  ///0->BLOCK; 1->FOOD; 2->BLACK Space
  int m[20][19]={
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,1,0},
{0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0},
{0,1,0,1,1,1,1,0,0,0,0,0,1,1,1,1,0,1,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,0,1,1,1,1,0,0,0,0,0,1,1,1,1,0,1,0},
{0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0},
{0,1,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};

for(i=0;i<20;i++)
{
  for(j=0;j<19;j++)
    map[i][j]=m[i][j];
}

death=0,dark=0;
score=0;
//initwindow(800,600);
maxx=getmaxx();
maxy=getmaxy();

//setviewport(0,0,maxx,maxy,1);
gridx=ceil(maxx/19);
gridy=ceil(maxy/20);
offset=(maxx%19)/2;
}

void initialize3()
{
  int i,j;
  ///0->BLOCK; 1->FOOD; 2->BLACK Space
 int m[20][19]={
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,1,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,1,0},
{0,1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0},
{0,0,0,0,1,0,0,0,2,0,2,0,0,0,1,0,0,0,0},
{0,1,1,1,1,0,2,2,2,2,2,2,2,0,1,1,1,1,0},
{0,1,0,0,1,0,2,0,0,2,0,0,2,0,1,0,0,1,0},
{0,1,1,1,1,0,2,2,2,2,2,2,2,0,1,1,1,1,0},
{0,1,0,0,1,0,2,0,2,0,2,0,2,0,1,0,0,1,0},
{0,1,1,1,1,0,2,2,2,2,2,2,2,0,1,1,1,1,0},
{0,0,0,0,1,0,2,0,0,0,0,0,2,0,1,0,0,0,0},
{0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0},
{0,1,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0},
{0,1,1,0,1,1,1,1,1,2,1,1,1,1,1,0,1,1,0},
{0,0,1,0,1,0,1,0,0,0,0,0,1,0,1,0,1,0,0},
{0,1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0},
{0,1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1,0},
{0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};

for(i=0;i<20;i++)
{
  for(j=0;j<19;j++)
    map[i][j]=m[i][j];
}

death=0,dark=0;
score=0;
//initwindow(800,600);
maxx=getmaxx();
maxy=getmaxy();

//setviewport(0,0,maxx,maxy,1);
gridx=ceil(maxx/19);
gridy=ceil(maxy/20);
offset=(maxx%19)/2;
}
///Initial position for PAcman & ghost
void initpos()
{
	x=9, y=14, x1=7, Y1=8, x2=11, Y2=8, x3= 7, y3=10, dir=0, st=120, end=60;
	tx2=14, tY2=14, r3=0;
}
///Start Window
void start()
{
	int i, n;
	settextstyle(3,0,3);
	outtextxy(500, maxy-50, "Press any key to start");
	setcolor(GREEN);
    settextstyle(3,0,6);
    outtextxy(250,200,"PACMAN ");
    setcolor(YELLOW);
    circle(360,300,30);
    setfillstyle(SOLID_FILL,YELLOW);
    floodfill(360,300,YELLOW);
    setcolor(BLACK);
    setfillstyle(SOLID_FILL,BLACK);
    pieslice(360,299,-25,40,40);


	getch();

	delay(15);

	cleardevice();

    int pos1 = 230;
    int pos2 = 90;
    int pos3 = 245;
    int pos4 = 95;
    setcolor(WHITE);
    setfillstyle(SOLID_FILL,WHITE);
    bar(pos1,pos2,pos3,pos4);
    //getch();
    int dir = 0,flagu = 0,flagd = 0,b = 0;
    while(true)
  {
    //delay(t);
    setcolor(GREEN);
    settextstyle(1,0,4);
    outtextxy(250,2,"PACMAN ");
    setcolor(3);
    settextstyle(3,0,1);
    outtextxy(250,80," New Game ");
    outtextxy(250,110," High Score");
    outtextxy(250,140," Select Level ");
    outtextxy(250,170," Instruction ");


    while(kbhit())
    {
      char c;
      c=getch();

      if(c==80 )///Down
        {
            dir++;
            flagu = 0;
            flagd = 1;
        }
      else if(c==72)///Up
      {
          dir--;
          flagu = 1;
          flagd = 0;
      }
      else if(c==13 )///Enter key (Need to found Keycode of enter)
      {
          b = 1;
          //break;
      }
      else
        continue ;
    setcolor(getbkcolor());
    setfillstyle(SOLID_FILL,getbkcolor());
    bar(pos1,pos2,pos3,pos4);

    if(dir==4){
            dir = 0;
            pos2 = 60;
            pos4 = 65;
    }
    if(dir<0){
        dir = 3;
        pos2 = 210;
        pos4 = 215;
    }
    if(b==1 && dir== 1){
        cleardevice();
        freopen("GameData.dat","r",stdin);
        scanf("%d",&highscore);
        sprintf(hc,"Bestscore: %d",highscore);
        setcolor(RED);
        settextstyle(1,0,4);
        outtextxy(280,110,hc);
        getch();
        getchar();
        cleardevice();
        b =0;

    }
    else if(b==1 && dir == 3){
        cleardevice();
        setcolor(GREEN);
        settextstyle(1,0,4);
        outtextxy(150,2,"INSTRUCTIONS ");
        setcolor(3);
        settextstyle(3,0,1);
        outtextxy(20,80," Your aim is to eat all the pellets ");
        outtextxy(20,140," But be careful! You must avoid");
        outtextxy(20,170," the ghosts trying to catch you! ");
        outtextxy(20,220," Use ARROY  to change directions ");
        outtextxy(20,250," Press Any Key To Continue ");
        outtextxy(20,280," Eat 50% Food To Level Up ");
        getch();
        cleardevice();
        b = 0;
    }

    else if(b==1 && dir==2 )///LEVEL
        {
        cleardevice();
         int fleu=0,fled=0,dirle=0,enter=0,fag = 1;
         int pp2 = 108;
        while(true){
        //setcolor(GREEN);


//    int pp3 = 275;
//    int pp4 = 125;
    setcolor(GREEN);
    settextstyle(3,0,3);
    outtextxy(260,pp2,">");
    settextstyle(1,0,4);


    outtextxy(240,2," LEVEL ");
    setcolor(3);
    settextstyle(3,0,1);
    outtextxy(280,110," DEFAULT ");
    outtextxy(280,140," LEVEL -1");
    outtextxy(280,170," LEVEL -2 ");
    outtextxy(280,200," LEVEL -3 ");
    outtextxy(280,230," LEVEL -4 ");
    outtextxy(280,260," LEVEL -5 ");
    outtextxy(280,290," LEVEL -6 ");


    while(kbhit())
    {
        char p;
        p=getch();
        if(p=='s' || p==80)///DOWN
        {
            dirle++;
//            pos2+=30;
            fleu=0;
            fled=1;
        }
        else if(p=='w' || p==72)///UP
        {
            dirle--;
//            pos2-=30;
              fleu=1;
            fled=0;
        }
        else if(p==13)
        {
            enter=1;
        }
        else continue;

        setcolor(getbkcolor());
        settextstyle(3,0,3);
        outtextxy(260,pp2,">");
    if(dirle>6)
    {
        dirle=0;
        pp2=108-30;
    }
   else if(dirle<0)
    {
        dirle=6;
        pp2=288+30;
    }
   if(fleu==1 && enter==0)
        pp2-=30;
    else if(fled==1 && enter==0)
        pp2+=30;
    if(enter==1){
        if(dirle==0)level = 1;
        else level = dirle;
        fag =0;
        break;
    }
//     setcolor(GREEN);
//       settextstyle(3,0,3);
//    outtextxy(260,pp2,">");
    }
    if(fag == 0){
           b =1 ;
           dir = 0;
            break;
    b =0 ;
    }
        }
    }

   // pos1 = 20;
    else if(flagd==1){
    pos2 += 30 ;
   // pos3 = 35;
    pos4 += 30;
    }
    else if(flagu==1){
        pos2 -= 30;
        pos4 -= 30;
    }

    setcolor(WHITE);
    setfillstyle(SOLID_FILL,WHITE);
    bar(pos1,pos2,pos3,pos4);
  }

	delay(15);
	if(b==1 && dir==0)break;
    else
        b=0;

}
  }



///Pacman Body Design
void slice(int p,int q,int sangle,int eangle,int rad)
{
  int i,j;

  if(sangle>eangle)
  {
    circle(p,q,rad);
    floodfill(p,q,YELLOW);
    setcolor(getbkcolor());
    setfillstyle(SOLID_FILL,getbkcolor());
    pieslice(p,q,eangle,sangle,rad);
    setcolor(YELLOW);
  }

  else
  {
    setfillstyle(SOLID_FILL,YELLOW);
    sector(p,q,sangle,eangle,rad,rad);
  }
}

void show1()
{
  int i,j;
  cleardevice();
///show1ing Block & Food
  for(i=0;i<20;i++)
  {
    for(j=0;j<19;j++)
    {
      switch(map[i][j])
      {
        case 0:///BLOCK
        setfillstyle(SOLID_FILL,GREEN);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
        break;

        case 1:///FOOD
        setcolor(WHITE);
        circle(j*gridx+gridx/2+offset, i*gridy+gridy/2,2);
        break;

        case 2:///BLACK SPACE
        setfillstyle(SOLID_FILL,BLACK);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;
      }
    }
  }
///PAcman
  setfillstyle(SOLID_FILL, YELLOW);
	setcolor(YELLOW);
	slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);
	///Ghost 1
	setcolor(RED);
	setfillstyle(SOLID_FILL, RED);
	circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
	floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

	setcolor(CYAN);///Ghost 2
	setfillstyle(SOLID_FILL, CYAN);
	circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
	floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

	setcolor(GREEN);///Ghost 3
	setfillstyle(SOLID_FILL, GREEN);
	circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
	floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

	///printf("\t\t\t\tPress Esc to Pause\t\tLives left: %2d", (3-death));
}

void show3()
{
  int i,j;
  cleardevice();
///show1ing Block & Food
  for(i=0;i<20;i++)
  {
    for(j=0;j<19;j++)
    {
      switch(map[i][j])
      {
        case 0:///BLOCK
        setfillstyle(SOLID_FILL,RED);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
        break;

        case 1:///FOOD
        setcolor(WHITE);
        circle(j*gridx+gridx/2+offset, i*gridy+gridy/2,2);
        break;

        case 2:///BLACK SPACE
        setfillstyle(SOLID_FILL,BLACK);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;
      }
    }
  }
///PAcman
  setfillstyle(SOLID_FILL, YELLOW);
	setcolor(YELLOW);
	slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);
	///Ghost 1
	setcolor(RED);
	setfillstyle(SOLID_FILL, RED);
	circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
	floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

	setcolor(CYAN);///Ghost 2
	setfillstyle(SOLID_FILL, CYAN);
	circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
	floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

	setcolor(GREEN);///Ghost 3
	setfillstyle(SOLID_FILL, GREEN);
	circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
	floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

	///printf("\t\t\t\tPress Esc to Pause\t\tLives left: %2d", (3-death));
}
void show5()
{
  int i,j;
  cleardevice();
///show1ing Block & Food
  for(i=0;i<20;i++)
  {
    for(j=0;j<19;j++)
    {
      switch(map[i][j])
      {
        case 0:///BLOCK
        setfillstyle(SOLID_FILL,YELLOW);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
        break;

        case 1:///FOOD
        setcolor(WHITE);
        circle(j*gridx+gridx/2+offset, i*gridy+gridy/2,2);
        break;

        case 2:///BLACK SPACE
        setfillstyle(SOLID_FILL,BLACK);
        bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;
      }
    }
  }
///PAcman
  setfillstyle(SOLID_FILL, YELLOW);
	setcolor(YELLOW);
	slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);
	///Ghost 1
	setcolor(RED);
	setfillstyle(SOLID_FILL, RED);
	circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
	floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

	setcolor(CYAN);///Ghost 2
	setfillstyle(SOLID_FILL, CYAN);
	circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
	floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

	setcolor(GREEN);///Ghost 3
	setfillstyle(SOLID_FILL, GREEN);
	circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
	floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

	///printf("\t\t\t\tPress Esc to Pause\t\tLives left: %2d", (3-death));
}



void update1(int l,int m)
{
  int i,j,r=1;
//  sprintf(sc,"%d",tot);///SCORE ON GRAPHICS CONSOLE
////  sprintf(hc,"%d",high);
//  setcolor(WHITE);
//  setviewport(offset,0,offset+120,gridy,1);
//  clearviewport();
//  outtextxy(offset,5,"Score: ");
  //outtextxy(offset+60,5,sc);



  setviewport(0,0,maxx,maxy,1);


  if(dark==1)
  {
    cleardevice();
    r=2;
  }
///Grid calculation after pacman eats food
  for(i=(m-r);i<=(m+r);i++)
  {
    for(j=(l-r);j<=(l+r);j++)
    {
      switch(map[i][j])
      {
        default:///GRID
		    setfillstyle(SOLID_FILL, GREEN);
		    bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;

		    case 1:///AFTER EATING FOOD THAT POSITION BECOME BLACK
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   setcolor(WHITE);
		   circle(j*gridx+gridx/2+offset, i*gridy+gridy/2, 2);
		   break;

		   case 2:/// Pacman disappear
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   break;
      }
    }
  }
        setfillstyle(SOLID_FILL, YELLOW);///pacman
		setcolor(YELLOW);
		slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);

		setcolor(RED);///ghost 1
		setfillstyle(SOLID_FILL, RED);
		circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
		floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

		setcolor(CYAN);///ghost 2
		setfillstyle(SOLID_FILL, CYAN);
		circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
		floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

        setcolor(GREEN);///ghost 3
		setfillstyle(SOLID_FILL, GREEN);
		circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
		floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

		setcolor(YELLOW);
}
void update3(int l,int m)
{
  int i,j,r=1;
//  sprintf(sc,"%d",tot);///SCORE ON GRAPHICS CONSOLE
//  setcolor(WHITE);
//  setviewport(offset,0,offset+120,gridy,1);
//  clearviewport();
//  outtextxy(offset,5,"Score: ");
//  outtextxy(offset+60,5,sc);
  setviewport(0,0,maxx,maxy,1);


  if(dark==1)
  {
    cleardevice();
    r=2;
  }
///Grid calculation after pacman eats food
  for(i=(m-r);i<=(m+r);i++)
  {
    for(j=(l-r);j<=(l+r);j++)
    {
      switch(map[i][j])
      {
        default:///GRID
		    setfillstyle(SOLID_FILL, RED);
		    bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;

		    case 1:///AFTER EATING FOOD THAT POSITION BECOME BLACK
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   setcolor(WHITE);
		   circle(j*gridx+gridx/2+offset, i*gridy+gridy/2, 2);
		   break;

		   case 2:
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   break;
      }
    }
  }
        setfillstyle(SOLID_FILL, YELLOW);///pacman
		setcolor(YELLOW);
		slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);

		setcolor(RED);///ghost 1
		setfillstyle(SOLID_FILL, RED);
		circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
		floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

		setcolor(CYAN);///ghost 2
		setfillstyle(SOLID_FILL, CYAN);
		circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
		floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

        setcolor(GREEN);///ghost 3
		setfillstyle(SOLID_FILL, GREEN);
		circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
		floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

		setcolor(YELLOW);
}
void update5(int l,int m)
{
  int i,j,r=1;
//  sprintf(sc,"%d",tot);///SCORE ON GRAPHICS CONSOLE
//  setcolor(WHITE);
//  setviewport(offset,0,offset+120,gridy,1);
//  clearviewport();
//  outtextxy(offset,5,"Score: ");
//  outtextxy(offset+60,5,sc);
  setviewport(0,0,maxx,maxy,1);


  if(dark==1)
  {
    cleardevice();
    r=2;
  }
///Grid calculation after pacman eats food
  for(i=(m-r);i<=(m+r);i++)
  {
    for(j=(l-r);j<=(l+r);j++)
    {
      switch(map[i][j])
      {
        default:///GRID
		    setfillstyle(SOLID_FILL, YELLOW);
		    bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		    break;

		    case 1:///AFTER EATING FOOD THAT POSITION BECOME BLACK
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   setcolor(WHITE);
		   circle(j*gridx+gridx/2+offset, i*gridy+gridy/2, 2);
		   break;

		   case 2:
		   setfillstyle(SOLID_FILL, BLACK);
		   bar(j*gridx+1+offset, i*gridy+1, (j+1)*gridx+offset, (i+1)*gridy);
		   break;
      }
    }
  }
        setfillstyle(SOLID_FILL, YELLOW);///pacman
		setcolor(YELLOW);
		slice(gridx*x+gridx/2+offset, gridy*y+gridy/2, st, end, gridy/2-2);

		setcolor(RED);///ghost 1
		setfillstyle(SOLID_FILL, RED);
		circle(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, gridy/2-2);
		floodfill(gridx*x1+gridx/2+offset, gridy*Y1+gridy/2, RED);

		setcolor(CYAN);///ghost 2
		setfillstyle(SOLID_FILL, CYAN);
		circle(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, gridy/2-2);
		floodfill(gridx*x2+gridx/2+offset, gridy*Y2+gridy/2, CYAN);

        setcolor(GREEN);///ghost 3
		setfillstyle(SOLID_FILL, GREEN);
		circle(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, gridy/2-2);
		floodfill(gridx*x3+gridx/2+offset, gridy*y3+gridy/2, GREEN);

		setcolor(YELLOW);
}


main()
{
    PlaySound(TEXT("Sound//baseline.wav"),NULL,SND_ASYNC);
  char c;
  int k;
  initialize();
  freopen("GameData.txt","r",stdin);
  scanf("%d",&highscore);
  if(rep==0)
    start();
  if(level==1 || level==2 )
  initialize1();
  else if(level==3 || level==4)
  initialize3();
  else if(level==6 || level==5)
  initialize5();

  initpos();
  if(level==1 || level==2)
  show1();
  else if(level==3 || level==4)
  show3();
  else if(level==6 || level==5)
  show5();




  delay(500);
  scs = 0;
  while(true)
  {
    delay(t);
        if(tot>highscore)highscore = tot;
        sprintf(hc,"Bestscore:   %d",highscore);
        outtextxy(maxx-200,0,hc);
        sprintf(sc,"SCORE :     %d",tot);
        outtextxy(10,0,sc);

        setcolor(RED);
        sprintf(lf,"LIFE REMAINING:   %d",3-death);
        outtextxy(maxx-500,0,lf);
    while(kbhit())
    {
        if(level%2==0)
                t=150;
            else t=300;
      c=getch();

      if(c=='w' || c=='W' || c==72)///UP
        dir=0;
      else if(c=='s' || c=='S'|| c==80)///DOWN
        dir=1;
      else if(c=='a' || c=='A'|| c==75)///LEFT
        dir=2;
      else if(c=='d' || c=='D' || c==77)///RIGHT
        dir=3;
      else if(c==27)
      {
        delay(15);
      }

    }

    if(dir==0)
    {
      if(map[y-1][x]==1)
      {
          scs++;
				score++;
				tot++;
          PlaySound(TEXT("Sound//pacman_eatfruit.wav"),NULL,SND_ASYNC);
        y--;
        map[y][x]=2;
        delay(50);


      }
      else if(map[y-1][x]==2)
        y--;
      st=120,end=60;
    }

    else if (dir==1)
		{
			if (map[y+1][x]==1)
			{
			    scs++;
				score++;
				tot++;
			    PlaySound(TEXT("Sound//pacman_eatfruit.wav"),NULL,SND_ASYNC);
				y++;
				map[y][x]=2;

				delay(50);


			}
			else if (map[y+1][x]==2)
			{
				y++;
			}
			st=300, end=240;
		}
    else if (dir==2)
		{
			if (map[y][x-1]==1)
			{
			    scs++;
				score++;
				tot++;
			    PlaySound(TEXT("Sound//pacman_eatfruit.wav"),NULL,SND_ASYNC);
				x--;

				map[y][x]=2;

				delay(50);


			}
			else if (map[y][x-1]==2)
			{
				x--;
			}
			st=210, end=150;
		}
		else if (dir==3)
		{
			if (map[y][x+1]==1)
			{
			    scs++;
				score++;
				tot++;
			    PlaySound(TEXT("Sound//pacman_eatfruit.wav"),NULL,SND_ASYNC);
				x++;
				map[y][x]=2;

				delay(50);


			}
			else if (map[y][x+1]==2)
			{
				x++;
			}
			st=30, end=330;
		}

    if((x==x1&&y==Y1)||(x==x2&&y==Y2)||(x==x3&&y==y3))///DEATH LOOP
		{

            PlaySound(TEXT("Sound//eat.wav"),NULL,SND_ASYNC);
			death++;

			for(k=6;k>=0;k--)
			{

				delay(50);
			}

			delay(750);
			initpos();
            if(level==1)
                show1();
            if(level==2)
                show1();
            if(level==3)
                show3();
            if(level==4)
                show3();
            if(level==5)
                show5();
            if(level==6)
                show5();


		}
        if(level==1)
		{
		    update1(x,y);
		    ghost1();
            ghost2();
		}
		if(level==2)
        {

             update1(x,y);
		    ghost1();
            ghost2();
        }
		if(level==3){
                update3(x,y);
                ghost1();
                ghost2();
                ghost3();
		}
if(level==4){
                update3(x,y);
                ghost1();
                ghost2();
                ghost3();
		}

		if(level==5){
                update5(x,y);
                ghost1();
                ghost2();
                ghost3();
		}
if(level==6){
                update5(x,y);
                ghost1();
                ghost2();
                ghost3();
		}
////////////////////////////////////////
/////////////// LEVEL UP //////////////
//////////////////////////////////////
		if ((score==90 && (level==1 || level==2)) || (score==75 && (level==3 || level==4)) || (score==90 && (level==5 || level==6)))
		{
			delay(500);
			level++;
			if(level>6) kill();


            cleardevice();
            outtextxy(maxx/2-40, maxy/2-50, "Next Level Loading");
            delay(1000);

			if(level==1)
			initialize1();
			if(level==2)
                initialize1();
            if(level==3)
                initialize3();
            if(level==4)
                initialize3();
            if(level==5)
                initialize5();
            if(level==6)
                initialize5();

            initpos();
            if(rep==0)
                score = 0;
            if(level==1)
                show1();
            if(level==2)
                show1();
            if(level==3)
                show3();
            if(level==4)
                show3();
            if(level==5)
                show5();
            if(level==6)
                show5();
            if(level==1)
                dir = 0;
		}
	}

}



void ghost1()
{
	int k, r=0;
	while(1)
	{
	if(r==2||(abs(Y1-y)>=abs(x1-x)&&r==0))
	{
		if (r==2||Y1>y)
		{
			if (map[Y1-1][x1]!=0)
			{
				Y1=Y1-1;
				break;
			}
		}
		else if (r==2||Y1<=y)
		{
			if (map[Y1+1][x1]!=0)
			{
				Y1=Y1+1;
                break;
			}
		}
	}
	else
	{
		if (r==2||x1>x)
		{
			if (map[Y1][x1-1]!=0)
			{
				x1=x1-1;
				break;
			}
		}
		else if (r==2||x1<=x)
		{
			if (map[Y1][x1+1]!=0)
			{
				x1=x1+1;
				break;
			}
		}
	}
	r++;
	if(r>3)
		break;
	}
		if(dark==0 && (level == 2 || level==1))
		update1(x1,Y1);
		else if(dark==0 && (level == 4 || level==3))
		update3(x1,Y1);
		else if(dark==0 && (level == 6 || level==5))
		update5(x1,Y1);

		if (x1==x&&Y1==y)
		{
		    PlaySound(TEXT("Sound//eat.wav"),NULL,SND_ASYNC);
			death++;
			for(k=6;k>=0;k--)
			{

				delay(50);
			}

			delay(750);
			if(death==3)
				kill();
			else

			{
				initpos();
				if(level==1)
                show1();
            if(level==2)
                show1();
            if(level==3)
                show3();
            if(level==4)
                show3();
            if(level==5)
                show5();
            if(level==6)
                show5();
			}
		}
}
void ghost2()
{
	int k, r=0;
	while(1)
	{
	if(r==2||(abs(Y2-tY2)>=abs(x2-tx2)&&r==0))
	{
		if (r==2||Y2>tY2)
		{
			if (map[Y2-1][x2]!=0)
			{
				Y2=Y2-1;
				break;
			}
		}
		else if (r==2||Y2<=tY2)
		{
			if (map[Y2+1][x2]!=0)
			{
				Y2=Y2+1;
				break;
			}
		}
	}
	else
	{
		if (r==2||x2>tx2)
		{
			if (map[Y2][x2-1]!=0)
			{
				x2=x2-1;
				break;
			}
		}
		else if (r==2||x2<=tx2)
		{
			if (map[Y2][x2+1]!=0)
			{
				x2=x2+1;
				break;
			}
		}
	}
	r++;
	if(r>3)
		break;
	}
		if(dark==0 && (level == 2 || level==1))
		update1(x2,Y2);
		else if(dark==0 && (level == 4 || level==3))
		update3(x2,Y2);
		else if(dark==0 && (level == 6 || level==5))
		update5(x2,Y2);
		if (x2==x&&Y2==y)
		{
		    PlaySound(TEXT("Sound//eat.wav"),NULL,SND_ASYNC);
			death++;

			delay(750);
			if(death==3)
				kill();
			else
			{
				initpos();
				if(level==1)
                show1();
            if(level==2)
                show1();
            if(level==3)
                show3();
            if(level==4)
                show3();
            if(level==5)
                show5();
            if(level==6)
                show5();
			}
		}
		if (x2==tx2&&Y2==tY2)
		{
			if(tx2==14&&tY2==14)
				tx2=4;
			else if(tx2==4&&tY2==14)
				tY2=2;
			else if(tx2==4&&tY2==2)
				tx2=14;
			else if(tx2==14&&tY2==2)
				tY2=14;
		}
}

void ghost3()
{
	int k, r=0, f=0;
	if((abs(x3-x)<=8&&abs(y3-y)<=8)&&r3<=8&&f==0)
	{
		tx3=x;
		ty3=y;
		r3++;
		if(r3==8)
		f=1;
	}
	else
	{
		tx3=19-x;
		ty3=20-y;
		if(f==1)
			r3++;
	}
	if(r3==16)
	{
		r3=0;
		f=0;
	}
	while(1)
	{
	if(r==2||(abs(y3-ty3)>=abs(x3-tx3)&&r==0))
	{
		if (r==2||y3>ty3)
		{
			if (map[y3-1][x3]!=0)
			{
				y3=y3-1;
				break;
			}
		}
		else if (r==2||y3<=ty3)
		{
			if (map[y3+1][x3]!=0)
			{
				y3=y3+1;
				break;
			}
		}
	}
	else
	{
		if (r==2||x3>tx3)
		{
			if (map[y3][x3-1]!=0)
			{
				x3=x3-1;
				break;
			}
		}
		else if (r==2||x3<=tx3)
		{
			if (map[y3][x3+1]!=0)
			{
				x3=x3+1;
				break;
			}
		}
	}
	r++;
	if(r>3)
		break;
	}
		if(dark==0 && (level == 2 || level==1))
		update1(x3,y3);
		else if(dark==0 && (level == 4 || level==3))
		update3(x3,y3);
		else if(dark==0 && (level == 6 || level==5))
		update5(x3,y3);
		if (x3==x&&y3==y)
		{
		    PlaySound(TEXT("Sound//eat.wav"),NULL,SND_ASYNC);
			death++;
			for(k=6;k>=0;k--)
			{

				delay(50);
			}

			delay(750);
			if(death==3)
				kill();
			else
			{
				initpos();
				if(level==1)
                show1();
            if(level==2)
                show1();
            if(level==3)
                show3();
            if(level==4)
                show3();
            if(level==5)
                show5();
            if(level==6)
                show5();
			}
		}
}

void kill()
{
	cleardevice();

	//////////////////////////////////////////////////
	////////////////DEFINE WIN ///////////////////////
	//////////////////////////////////////////////////

freopen("GameData.txt","w",stdout);
if(tot>=highscore)
   printf("%d\n",tot);
else
 printf("%d\n",highscore);
	if (tot==530 || level>6 && death<3)
	{
        PlaySound(TEXT("Sound//Win.wav"),NULL,SND_ASYNC);
		outtextxy(maxx/2-40, maxy/2-50, "YOU WIN!");
		outtextxy(maxx/2-180, maxy-50, "(Esc to exit)");
	}
	else if (death>=3)
	{
PlaySound(TEXT("Sound//DDeath.wav"),NULL,SND_ASYNC);
		outtextxy(maxx/2-46, maxy/2-50, "GAME OVER!");
		outtextxy(maxx/2-190, maxy-50, "( Esc to exit)");
		sprintf(sc,"Score : %d ",tot);
		//outtextxy(maxx/2-40, maxy/2-20,"Score: ");
		outtextxy(maxx/2-46, maxy/2-20,sc);
//		if(tot>=highscore)freopen("GameData.txt","w",stdout);
	}
	else
	{
		outtextxy(maxx/2-46, maxy/2-50, "GAME PAUSED");
		//sprintf(sc, "%d", tot);
		sprintf(sc,"Score : %d ",tot);
		//outtextxy(maxx/2-40, maxy/2-20,"Score:    ");
		outtextxy(maxx/2+35, maxy/2-20,sc);
	}
	delay(750);
	while(1)
	{	ch=getch();
		if (ch==' ')
		{
			rep=1;
			//main();
			cleardevice();
			exit(0);
		}
		else if (ch==27)
		{
			cleardevice();
			exit(0);
		}

	}
}
